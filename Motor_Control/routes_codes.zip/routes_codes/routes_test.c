#include <stdio.h>
#include <stdlib.h>
#include "routes.h"

void print_func(unsigned char command, unsigned long duration)
{
	printf("%c, %ld\n", command, duration);
}

int main()
{
	struct route_t *route = init_route(0);

	add_command(route, 'F', 5000);
	add_command(route, 'B', 5000);
	add_command(route, 'L', 3000);
	add_command(route, 'R', 2000);

	perform_route(*route, FORWARD, print_func, invert_command);
	delete_command(route, END);
	delete_command(route, START);
	perform_route(*route, REVERSE, print_func, invert_command);
}
